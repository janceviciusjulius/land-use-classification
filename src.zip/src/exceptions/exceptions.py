class InvalidParameterException(Exception):
    pass


class MonthExtractionException(Exception):
    pass
