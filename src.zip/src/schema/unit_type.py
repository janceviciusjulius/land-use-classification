from enum import Enum


class UnitType(str, Enum):
    FILE = "file"
    PACKAGE = "package"
