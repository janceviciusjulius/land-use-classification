from enum import Enum


class AccuracyMetrics(str, Enum):
    ACCURACY_WEIGHTED = "weighted"
